package com.example.testiny;

public class Question
{
    int questionNumber;
    String description;
    String mistakeDescription;
    boolean isCorrect;

    public Question()
    {

    }

    public void setQuestionNumber (int number)
    {
        this.questionNumber = number;
    }

    public int getQuestionNumber()
    {
        return questionNumber;
    }

    public void setDescription (String description)
    {
        this.description = description;
    }

    public String getDescription()
    {
        return description;
    }

    public void setMistakeDescription (String mistakeDescription)
    {
        this.mistakeDescription = mistakeDescription;
    }

    public String getMistakeDescription()
    {
        return mistakeDescription;
    }

    public void setCorrect (String correct)
    {
        this.isCorrect = Boolean.parseBoolean(correct);
    }

    public boolean getCorrect()
    {
        return isCorrect;
    }
}
