package com.example.testiny;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.View.OnClickListener;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth maAuth;
    private TextView maEmail;
    private Button maLogout, maDoNext;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        maAuth = FirebaseAuth.getInstance();

        maLogout= findViewById(R.id.btnLogoutM);
        maEmail = findViewById(R.id.txtEmailM);

        maDoNext = findViewById(R.id.btnNextDoM);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String roleUser = prefs.getString("key-role", "no role");
        String nameUser = prefs.getString("key-username", "untitled");

        FirebaseUser currentUser = maAuth.getCurrentUser();
        if (currentUser == null) {
//No one signed in
            startActivity(new Intent(this, SignInActivity.class));
            this.finish();
        }else {
//User logged in
            maEmail.setText(nameUser + ", your role is " + roleUser);

            switch (roleUser)
            {
                case "Student":
                    maDoNext.setText("Find your test by id");
                    break;
                case "Teacher":
                    Log.i("CASE-PROBLEM", "Teacher");
                    maDoNext.setText("Create new test");
                    break;
                default:
                    maDoNext.setText("No account role specified");
            }
        }

        maLogout.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                /*
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = prefs.edit();
                editor.clear();
                editor.commit();
                */
                maAuth.signOut();
                startActivity(new Intent(MainActivity.this, SignInActivity.class));
                MainActivity.this.finish();

            }
        });

        maDoNext.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {

                if (roleUser.equals("Student"))
                {
                    startActivity(new Intent(MainActivity.this, FindTestActivity.class));
                    MainActivity.this.finish();

                } else if (roleUser.equals("Teacher"))
                {
                    startActivity(new Intent(MainActivity.this, TestDescActivity.class));
                    MainActivity.this.finish();
                }
            }
        });




    }


}
