package com.example.testiny;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class OngoingTestActivity extends AppCompatActivity implements View.OnClickListener {

    private String ongoingTestID;
    private int ongoingTestQuestionNumber;
    private int correctAnswers;
    private int currentQuestionNumber;
    private boolean isFirst;

    private Button otTrue, otFalse, otNext;
    private TextView otHeader, otQuestion, otMistake;

    private ArrayList<Question> questionBank;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ongoing_test);



        otTrue = findViewById(R.id.btnTrueOT);
        otFalse = findViewById(R.id.btnFalseOT);
        otNext = findViewById(R.id.btnNextOT);

        otHeader = findViewById(R.id.txtHeaderOT);
        otQuestion = findViewById(R.id.txtQuestionOT);
        otMistake = findViewById(R.id.txtMistakeOT);


        Intent receivedIntent = getIntent();
        ongoingTestID = receivedIntent.getStringExtra("test_id");
        ongoingTestQuestionNumber = receivedIntent.getIntExtra("number_of_questions", 1);
        Log.i("NUMBER OF QUEST", String.valueOf(ongoingTestQuestionNumber));
        correctAnswers = 0;
        currentQuestionNumber = 1;
        isFirst = true;

        questionBank = new ArrayList<Question>();



        FirebaseDatabase database = FirebaseDatabase.getInstance();

        for (int i = 1; i <= ongoingTestQuestionNumber; i++) {
            DatabaseReference questionPath = database.getReference("test/" + ongoingTestID + "/" + i);
            Log.i("TEST DESC", String.valueOf(i));
            questionPath.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        Question receivedQuestion = new Question();

                        Long qNumber = dataSnapshot.child("questionNumber").getValue(Long.class);
                        receivedQuestion.setQuestionNumber(qNumber.intValue());
                        receivedQuestion.setDescription(dataSnapshot.child("description").getValue(String.class));
                        receivedQuestion.setMistakeDescription(dataSnapshot.child("mistakeDescription").getValue(String.class));
                        boolean whatCorrect = dataSnapshot.child("correct").getValue(Boolean.class);
                        receivedQuestion.setCorrect(String.valueOf(whatCorrect));

                        questionBank.add(receivedQuestion);
                        Log.i("TEST DESC", receivedQuestion.getDescription());
                        if (isFirst)
                        {
                            otHeader.setText("Question " + questionBank.get(0).getQuestionNumber());
                            otQuestion.setText(questionBank.get(0).getDescription());
                            otMistake.setText("");
                            isFirst = false;

                        }
                    }

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                }

            });
        }


        otTrue.setOnClickListener(this);
        otFalse.setOnClickListener(this);
        otNext.setOnClickListener(this);

        otNext.setEnabled(false);


    }


    public void onClick (View v)
    {
        Log.i("correct?", String.valueOf(correctAnswers));
        if (currentQuestionNumber <= ongoingTestQuestionNumber)
        {
            switch (v.getId())
            {
                case R.id.btnTrueOT:
                    if (questionBank.get(currentQuestionNumber - 1).getCorrect() == true)
                    {
                        correctAnswers++;
                        otTrue.setEnabled(false);
                        otFalse.setEnabled(false);
                        otNext.setEnabled(true);
                        otMistake.setText("Correct!");
                    } else {
                        Log.i("mistake", questionBank.get(currentQuestionNumber - 1).getMistakeDescription());
                        otMistake.setText(questionBank.get(currentQuestionNumber - 1).getMistakeDescription());
                        otTrue.setEnabled(false);
                        otFalse.setEnabled(false);
                        otNext.setEnabled(true);

                    }
                    break;
                case R.id.btnFalseOT:
                    if (questionBank.get(currentQuestionNumber - 1).getCorrect() == false)
                    {
                        correctAnswers++;
                        otTrue.setEnabled(false);
                        otFalse.setEnabled(false);
                        otNext.setEnabled(true);
                        otMistake.setText("Correct!");
                    } else {
                        Log.i("mistake", questionBank.get(currentQuestionNumber - 1).getMistakeDescription());
                        otMistake.setText(questionBank.get(currentQuestionNumber - 1).getMistakeDescription());
                        otTrue.setEnabled(false);
                        otFalse.setEnabled(false);
                        otNext.setEnabled(true);
                    }

                    break;
                case R.id.btnNextOT:
                    otTrue.setEnabled(true);
                    otFalse.setEnabled(true);
                    otNext.setEnabled(false);

                    currentQuestionNumber++;

                    if (currentQuestionNumber <= ongoingTestQuestionNumber) {
                        otHeader.setText("Question " + questionBank.get(currentQuestionNumber - 1).getQuestionNumber());
                        otQuestion.setText(questionBank.get(currentQuestionNumber - 1).getDescription());
                        otMistake.setText("");
                    } else {
                        otTrue.setEnabled(false);
                        otFalse.setEnabled(false);
                        otNext.setEnabled(true);
                        otNext.setText("Finish Test");

                    }

                    break;
                default:
                    break;

            }
        } else
        {
            Intent completedTest = new Intent(OngoingTestActivity.this, TestResultsActivity.class);
            completedTest.putExtra("test_results", correctAnswers);
            completedTest.putExtra("number_of_questions", ongoingTestQuestionNumber);
            startActivity(completedTest);
            OngoingTestActivity.this.finish();
        }
    }
}
