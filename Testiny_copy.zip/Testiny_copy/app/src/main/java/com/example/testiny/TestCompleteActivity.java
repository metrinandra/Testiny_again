package com.example.testiny;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class TestCompleteActivity extends AppCompatActivity {

    private String createdTestID;

    private TextView tcID;
    private Button tcReturn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_complete);

        Intent receivedIntent = getIntent();
        createdTestID = receivedIntent.getStringExtra("test_id");

        tcID = findViewById(R.id.txtIDTC);
        tcID.setText(createdTestID);

        tcReturn = findViewById(R.id.btnReturnTC);

        tcReturn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(new Intent(TestCompleteActivity.this, MainActivity.class));

                finish();

            }
        });
    }


}
