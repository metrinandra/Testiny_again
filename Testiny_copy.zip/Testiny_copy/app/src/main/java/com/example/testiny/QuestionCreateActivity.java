package com.example.testiny;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class QuestionCreateActivity extends AppCompatActivity {

    private int numberOfQuestions;
    private String TestID;
    private int currentQuestionNumber;
    private ArrayList<Question> questionBank;

    private TextView qcNumber;
    private EditText qcTitle, qcMistakeDesc;

    private Spinner qcCorrect;
    private String[] userChoices;
    private ArrayAdapter<String> adapter;

    private Button qcSaveQuest;

    private String correctChoice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_create);

        Intent receivedIntent = getIntent();
        numberOfQuestions = receivedIntent.getIntExtra("number_of_questions", 1);
        TestID = receivedIntent.getStringExtra("test_id");
        currentQuestionNumber = 1;

        questionBank = new ArrayList<Question>();
        qcNumber = findViewById(R.id.txtQuestNumberQC);
        qcNumber.setText("Question " + currentQuestionNumber);

        qcTitle = findViewById(R.id.txtQuestionQC);
        qcMistakeDesc = findViewById(R.id.txtMistakeDescQC);

        qcCorrect = findViewById(R.id.spnrCorrectQC);
        qcSaveQuest = findViewById(R.id.btnSaveQuestQC);


        userChoices = new String[]{"True", "False"};
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, userChoices);
        qcCorrect.setAdapter(adapter);

        qcCorrect.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view,
                                       int position, long id) {
                Object item = adapterView.getItemAtPosition(position);
                if (item != null)
                {
                    correctChoice = item.toString();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // TODO Auto-generated method stub
                correctChoice = "True";

            }
        });

        qcSaveQuest.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if (currentQuestionNumber < numberOfQuestions)
                {
                    Question UserQuestion = new Question();
                    UserQuestion.setQuestionNumber(currentQuestionNumber);
                    UserQuestion.setDescription(qcTitle.getText().toString());
                    UserQuestion.setMistakeDescription(qcMistakeDesc.getText().toString());
                    UserQuestion.setCorrect(correctChoice);

                    questionBank.add(UserQuestion);

                    Toast.makeText(QuestionCreateActivity.this, "Question saved!",
                        Toast.LENGTH_SHORT).show();

                    qcTitle.getText().clear();
                    qcMistakeDesc.getText().clear();

                    currentQuestionNumber++;
                    qcNumber.setText("Question " + currentQuestionNumber);

                } else if (currentQuestionNumber == numberOfQuestions){
                    Question UserQuestion = new Question();
                    UserQuestion.setQuestionNumber(currentQuestionNumber);
                    UserQuestion.setDescription(qcTitle.getText().toString());
                    UserQuestion.setMistakeDescription(qcMistakeDesc.getText().toString());
                    UserQuestion.setCorrect(correctChoice);

                    questionBank.add(UserQuestion);


                    currentQuestionNumber++;

                    FirebaseDatabase database = FirebaseDatabase.getInstance();


                    for (int i = 0; i < questionBank.size(); i ++)
                    {
                        int questionRealNumber = i + 1;
                        Log.i("HOW MANY ADDED", "cool");
                        DatabaseReference questionRef = database.getReference("test/" + TestID + "/" + questionRealNumber);
                        questionRef.setValue(questionBank.get(i));
                    }

                    Intent completeIntent = new Intent(QuestionCreateActivity.this, TestCompleteActivity.class);
                    completeIntent.putExtra("test_id", TestID);
                    startActivity(completeIntent);
                    QuestionCreateActivity.this.finish();

                }



            }
        });



    }
}
