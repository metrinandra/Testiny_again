package com.example.testiny;

public enum Role
{
    Teacher,
    Student
}
