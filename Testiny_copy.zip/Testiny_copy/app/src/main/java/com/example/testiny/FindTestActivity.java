package com.example.testiny;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class FindTestActivity extends AppCompatActivity {

    private Button ftSearch, ftStart;
    private TextView ftTitle, ftDescription;
    private EditText ftID;
    private RelativeLayout rootFT, fadingFT;
    private ProgressBar ftPrBar;

    private Test foundTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_test);

        ftSearch = findViewById(R.id.btnSearchFT);
        ftStart = findViewById(R.id.btnStartFT);

        ftTitle = findViewById(R.id.txtTestTitleFT);
        ftDescription = findViewById(R.id.txtTestDescFT);

        ftID = findViewById(R.id.txtTestIDFT);

        rootFT = findViewById(R.id.rltvLayoutRootFT);
        fadingFT = findViewById(R.id.rltvLayoutFadingFT);
        ftPrBar = findViewById(R.id.prBarFT);

        foundTest = new Test();

        ftStart.setEnabled(false);
        fadingFT.setVisibility(View.INVISIBLE);


        ftSearch.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                fadingFT.setVisibility(View.VISIBLE);
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference testPath = database.getReference("test/" + ftID.getText().toString());

                testPath.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot)
                    {
                        if (dataSnapshot.exists()) {
                            foundTest.setDescription(dataSnapshot.child("description").getValue(String.class));
                            String id = dataSnapshot.child("id").getValue(String.class);
                            foundTest.setID(Integer.parseInt(id.substring(2)));
                            Long numberQuestions = dataSnapshot.child("numberOfQuestions").getValue(Long.class);
                            foundTest.setNumberOfQuestions(numberQuestions.intValue());
                            foundTest.setTitle(dataSnapshot.child("title").getValue(String.class));
                            foundTest.setType(dataSnapshot.child("type").getValue(String.class));
                            Log.i("TEST DESC", foundTest.getDescription());

                            fadingFT.setVisibility(View.INVISIBLE);

                            ftTitle.setText(foundTest.getID() + ": " + foundTest.getTitle() + " (" + foundTest.getType() + ")");
                            ftStart.setEnabled(true);
                            ftDescription.setText(foundTest.getDescription());
                        } else
                        {
                            fadingFT.setVisibility(View.INVISIBLE);
                            ftTitle.setText("Nothing found!");
                            ftDescription.setText("");
                            ftStart.setEnabled(false);
                        }

                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }

                });


            }
        });


        ftStart.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                Intent testStartIntent = new Intent(FindTestActivity.this, OngoingTestActivity.class);
                testStartIntent.putExtra("number_of_questions", foundTest.getNumberOfQuestions());
                testStartIntent.putExtra("test_id", foundTest.getID());
                startActivity(testStartIntent);
                FindTestActivity.this.finish();
            }
        });


    }
}
