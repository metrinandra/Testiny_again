package com.example.testiny;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SignInActivity extends AppCompatActivity {

    private Button siBtnSignIn, siBtnSignUp;
    private EditText siEntEmail, siEntPassword;
    private RelativeLayout siRlLayout, siRlFadingLayout;
    private ProgressBar siProgressBar;

    private String loggedUserEmail;


    private User loggingUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        siBtnSignIn = findViewById(R.id.btnLoginSI);
        siBtnSignUp = findViewById(R.id.btnNextDoM);
        siEntEmail = findViewById(R.id.txtEmailAddressSI);
        siEntPassword = findViewById(R.id.txtPasswordSI);
        siRlLayout = findViewById(R.id.rltvLayoutRoot);
        siRlFadingLayout = findViewById(R.id.rltvLayoutSI);
        siProgressBar = findViewById(R.id.prBarSI);

        siProgressBar.setVisibility(View.INVISIBLE);
        siRlFadingLayout.setVisibility(View.INVISIBLE);




        siBtnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SignInActivity.this, SignUpActivity.class));
                finish();
            }
        });

              siBtnSignIn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String email = siEntEmail.getText().toString();
                    String password = siEntPassword.getText().toString();

                    siProgressBar.setVisibility(View.VISIBLE);
                    siRlFadingLayout.setVisibility(View.VISIBLE);

                    final FirebaseDatabase database = FirebaseDatabase.getInstance();

                    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
                    firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(
                        new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {


                                if (task.isSuccessful()) {

                                    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
                                    DatabaseReference ref = database.getReference("users/" + currentUser.getDisplayName());

                                    ref.child("role").addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot)
                                        {
                                            String userRole = dataSnapshot.getValue().toString();
                                            Log.i("role-problem", userRole);

                                            loggingUser = new User();
                                            loggingUser.setUserNickName(currentUser.getDisplayName());
                                            loggingUser.setUserEmail(currentUser.getEmail());
                                            loggingUser.setRole(userRole);

                                            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                                            SharedPreferences.Editor editor = prefs.edit();

                                            editor.putString("key-username", loggingUser.getUserNickName());
                                            editor.putString("key-email", loggingUser.getUserEmail());
                                            editor.putString("key-role", userRole);
                                            editor.commit();

                                        }
                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {
                                            // ...
                                        }
                                    });

                                    startActivity(new Intent(SignInActivity.this, MainActivity.class));
                                    finish();
                                } else {
                                    siProgressBar.setVisibility(View.INVISIBLE);
                                    siRlFadingLayout.setVisibility(View.INVISIBLE);
                                    Snackbar
                                        .make(siRlLayout, task.getException().getLocalizedMessage(), Snackbar.LENGTH_LONG)
                                        .show();
                                }
                            }
                        });

                }
        });

    }
}
