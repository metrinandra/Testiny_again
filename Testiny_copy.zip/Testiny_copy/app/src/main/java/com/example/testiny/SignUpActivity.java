package com.example.testiny;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUpActivity extends AppCompatActivity {

    private EditText suEmail, suPassword, suPasswordConfirm, suNickname;
    private Button suSignUp;
    private RelativeLayout suRoot, suFading;
    private ProgressBar suPrBar;

    private Spinner suDropdown;
    private String[] roles;
    private ArrayAdapter<String> adapter;

    private FirebaseAuth suAuth;
    public User newUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        suEmail = findViewById(R.id.txtEmailAddressSU);
        suPassword = findViewById(R.id.txtPasswordSU);
        suPasswordConfirm = findViewById(R.id.txtPasswordConfirmSU);
        suNickname = findViewById(R.id.txtNickNameSU);
        suSignUp = findViewById(R.id.btnSignUpSU);
        suRoot = findViewById(R.id.rltvLayoutRootSU);
        suFading = findViewById(R.id.rltvLayoutFadingSU);
        suPrBar = findViewById(R.id.prBarSU);


        suDropdown = (Spinner) findViewById(R.id.spnrRolePickerSU);
        roles = new String[]{Role.Student.toString(), Role.Teacher.toString()};
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, roles);
        suDropdown.setAdapter(adapter);

        suDropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view,
                                       int position, long id) {
                Object item = adapterView.getItemAtPosition(position);
                if (item != null)
                {
                    Toast.makeText(SignUpActivity.this, item.toString(),
                        Toast.LENGTH_SHORT).show();

                    newUser = null;

                    newUser = new User();
                    newUser.setRole(item.toString());
                    System.out.println();


                }
                //Toast.makeText(SignUpActivity.this, "Selected",
                 //   Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // TODO Auto-generated method stub

            }
        });

        suSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = suEmail.getText().toString();
                String name = suNickname.getText().toString();
                String pass = suPassword.getText().toString();
                String confirmPass = suPasswordConfirm.getText().toString();

                newUser.setUserEmail(email);
                newUser.setUserNickName(name);



                if (!pass.equals(confirmPass)) {
                    Snackbar.make(suRoot, "Password Doesn't match", Snackbar.LENGTH_LONG).show();
                } else {
                    //suPrBar.setVisibility(View.VISIBLE);
                    //suFading.setVisibility(View.VISIBLE);

                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference userRef = database.getReference("users/" + newUser.getUserNickName());

                    userRef.setValue(newUser);

                    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    SharedPreferences.Editor editor = prefs.edit();

                    editor.putString("key-username", newUser.getUserNickName());
                    editor.putString("key-email", newUser.getUserEmail());
                    editor.putString("key-role", newUser.getRole());
                    editor.commit();


                    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
                    firebaseAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(
                        new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {

                                if (task.isSuccessful()) {

                                    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();


                                    UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                        .setDisplayName(newUser.getUserNickName())
                                        .build();

                                    currentUser.updateProfile(profileUpdates)
                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {
                                                if (task.isSuccessful()) {
                                                    //Log.d(TAG, "User profile updated.");
                                                }
                                            }
                                        });


                                    Toast.makeText(SignUpActivity.this, "SignUp Complete", Toast.LENGTH_SHORT)
                                        .show();
                                    startActivity(new Intent(SignUpActivity.this, MainActivity.class));

                                    finish();
                                } else {
                                    Snackbar.make(suRoot, task.getException().getMessage(), Snackbar.LENGTH_LONG)
                                        .show();
                                }

                            }
                        });
                }


            }
        });

    }
}
