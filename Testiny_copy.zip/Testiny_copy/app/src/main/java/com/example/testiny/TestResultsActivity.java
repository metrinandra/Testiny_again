package com.example.testiny;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class TestResultsActivity extends AppCompatActivity {

    private int totalCorrect;
    private int totalCount;

    private TextView trResults;
    private Button trReturn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_results);

        Intent receivedIntent = getIntent();
        totalCorrect = receivedIntent.getIntExtra("test_results", 1);
        totalCount = receivedIntent.getIntExtra("number_of_questions", 1);

        trResults = findViewById(R.id.txtResultsTR);
        trResults.setText(totalCorrect + " out of " + totalCount);

        trReturn = findViewById(R.id.btnReturnTR);

        trReturn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                startActivity(new Intent(TestResultsActivity.this, MainActivity.class));

                finish();

            }
        });
    }
}
