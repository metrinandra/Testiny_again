package com.example.testiny;

public enum Category
{
    Mixed,
    Science,
    Math,
    Language,
    History,
    Art
}
