package com.example.testiny;

import java.util.Date;

public class User
{
    String email;
    String nickName;
    Role role;
    Date whenCreated;

    public User()
    {
        this.whenCreated = new Date();
    }

    public User (String email, String nickname)
    {
        this.email = email;
        this.nickName = nickname;
        this.whenCreated = new Date();
    }

    public String getUserEmail()
    {
        return email;
    }

    public void setUserEmail(String email)
    {
        this.email = email;
    }

    public String getUserNickName()
    {
        return nickName;
    }

    public void setUserNickName(String nickName)
    {
        this.nickName = nickName;
    }

    public String whenUserCreated()
    {
        return whenCreated.toString();
    }

    public void setRole(String r)
    {
         role = Role.valueOf(r);
    }

    public String getRole()
    {
        return role.toString();
    }

}


