package com.example.testiny;

public class Test
{
    String ID;
    String title;
    String description;
    Category type;
    int numberOfQuestions;


    public Test(){};

    public void setID(int number)
    {
        this.ID = "ID" + number;
    }

    public String getID()
    {
        return ID;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getTitle()
    {
        return title;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getDescription()
    {
        return description;
    }

    public void setType(String c)
    {
        type = Category.valueOf(c);
    }

    public String getType()
    {
        return type.toString();
    }

    public void setNumberOfQuestions(int number)
    {
        this.numberOfQuestions = number;
    }

    public int getNumberOfQuestions()
    {
        return numberOfQuestions;
    }
}
