package com.example.testiny;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.InputFilter;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class TestDescActivity extends AppCompatActivity {

    private EditText tdTitle, tdDescription, tdQuestionNumber;
    private Button tdCreateTest;

    private Spinner tdSpinner;
    private String[] allCategories;
    private ArrayAdapter<String> adapter;

    private int previousTestNumber;

    public Test newUserTest;
    private int number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_desc);

        tdDescription = findViewById(R.id.txtTestDescTD);
        tdTitle = findViewById(R.id.txtTestTitleTD);
        tdCreateTest = findViewById(R.id.btnCreateTestTD);

        tdQuestionNumber = findViewById(R.id.txtQuestNumberTD);
        tdQuestionNumber.setFilters(new InputFilter[]{new InputFilterMinMax("1", "30")});

        newUserTest = new Test();


        tdSpinner = findViewById(R.id.spnrCategoryPickerTD);
        allCategories = new String[]{Category.Mixed.toString(), Category.Art.toString(), Category.History.toString(), Category.Language.toString(),
            Category.Math.toString(), Category.Science.toString()};
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, allCategories);
        tdSpinner.setAdapter(adapter);

        tdSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view,
                                       int position, long id) {
                Object item = adapterView.getItemAtPosition(position);
                if (item != null)
                {
                    Toast.makeText(TestDescActivity.this, item.toString(),
                        Toast.LENGTH_SHORT).show();

                        newUserTest = null;

                        newUserTest = new Test();
                        newUserTest.setType(item.toString());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // TODO Auto-generated method stub
                newUserTest.setType("Mixed");

            }
        });

        tdCreateTest.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {



                newUserTest.setTitle(tdTitle.getText().toString());
                newUserTest.setDescription(tdDescription.getText().toString());
                newUserTest.setNumberOfQuestions(Integer.parseInt(tdQuestionNumber.getText().toString()));


                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference numberRef = database.getReference("id-generator");

                numberRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot)
                    {
                        previousTestNumber = Integer.parseInt(dataSnapshot.getValue().toString());
                        newUserTest.setID(Integer.parseInt(dataSnapshot.getValue().toString()));
                        previousTestNumber++;
                        numberRef.setValue(previousTestNumber);

                        DatabaseReference testPath = database.getReference("test/" + newUserTest.getID());
                        testPath.setValue(newUserTest);

                        Intent questionIntent = new Intent(TestDescActivity.this, QuestionCreateActivity.class);
                        questionIntent.putExtra("number_of_questions", newUserTest.getNumberOfQuestions());
                        questionIntent.putExtra("test_id", newUserTest.getID());
                        startActivity(questionIntent);
                        TestDescActivity.this.finish();


                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        // ...
                    }

                });


            }


        });




    }
}
